﻿namespace OOAD_Project
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.enableSpeak = new System.Windows.Forms.Button();
            this.disableSpeak = new System.Windows.Forms.Button();
            this.enableTextSpeech = new System.Windows.Forms.Button();
            this.disableTextSpeech = new System.Windows.Forms.Button();
            this.writeText = new System.Windows.Forms.RichTextBox();
            this.speechText = new System.Windows.Forms.RichTextBox();
            this.play = new System.Windows.Forms.Button();
            this.pause = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // enableSpeak
            // 
            this.enableSpeak.Location = new System.Drawing.Point(12, 241);
            this.enableSpeak.Name = "enableSpeak";
            this.enableSpeak.Size = new System.Drawing.Size(105, 66);
            this.enableSpeak.TabIndex = 0;
            this.enableSpeak.Text = "Enable Speak";
            this.enableSpeak.UseVisualStyleBackColor = true;
            this.enableSpeak.Click += new System.EventHandler(this.enableSpeak_Click);
            // 
            // disableSpeak
            // 
            this.disableSpeak.Location = new System.Drawing.Point(134, 241);
            this.disableSpeak.Name = "disableSpeak";
            this.disableSpeak.Size = new System.Drawing.Size(105, 66);
            this.disableSpeak.TabIndex = 1;
            this.disableSpeak.Text = "Disable Speak";
            this.disableSpeak.UseVisualStyleBackColor = true;
            this.disableSpeak.Click += new System.EventHandler(this.disableSpeak_Click);
            // 
            // enableTextSpeech
            // 
            this.enableTextSpeech.Location = new System.Drawing.Point(260, 241);
            this.enableTextSpeech.Name = "enableTextSpeech";
            this.enableTextSpeech.Size = new System.Drawing.Size(105, 66);
            this.enableTextSpeech.TabIndex = 2;
            this.enableTextSpeech.Text = "Enable Text Speech";
            this.enableTextSpeech.UseVisualStyleBackColor = true;
            this.enableTextSpeech.Click += new System.EventHandler(this.enableTextSpeech_Click);
            // 
            // disableTextSpeech
            // 
            this.disableTextSpeech.Location = new System.Drawing.Point(387, 241);
            this.disableTextSpeech.Name = "disableTextSpeech";
            this.disableTextSpeech.Size = new System.Drawing.Size(105, 66);
            this.disableTextSpeech.TabIndex = 3;
            this.disableTextSpeech.Text = "Disable Text Speech";
            this.disableTextSpeech.UseVisualStyleBackColor = true;
            this.disableTextSpeech.Click += new System.EventHandler(this.disableTextSpeech_Click);
            // 
            // writeText
            // 
            this.writeText.Location = new System.Drawing.Point(12, 12);
            this.writeText.Name = "writeText";
            this.writeText.Size = new System.Drawing.Size(480, 96);
            this.writeText.TabIndex = 4;
            this.writeText.Text = "";
            this.writeText.TextChanged += new System.EventHandler(this.writeText_TextChanged);
            // 
            // speechText
            // 
            this.speechText.Enabled = false;
            this.speechText.Location = new System.Drawing.Point(12, 123);
            this.speechText.Name = "speechText";
            this.speechText.Size = new System.Drawing.Size(480, 95);
            this.speechText.TabIndex = 5;
            this.speechText.Text = "";
            this.speechText.TextChanged += new System.EventHandler(this.speechText_TextChanged);
            // 
            // play
            // 
            this.play.Location = new System.Drawing.Point(12, 344);
            this.play.Name = "play";
            this.play.Size = new System.Drawing.Size(105, 60);
            this.play.TabIndex = 6;
            this.play.Text = "play";
            this.play.UseVisualStyleBackColor = true;
            this.play.Click += new System.EventHandler(this.play_Click);
            // 
            // pause
            // 
            this.pause.Location = new System.Drawing.Point(134, 344);
            this.pause.Name = "pause";
            this.pause.Size = new System.Drawing.Size(105, 60);
            this.pause.TabIndex = 7;
            this.pause.Text = "pause";
            this.pause.UseVisualStyleBackColor = true;
            this.pause.Click += new System.EventHandler(this.pause_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(537, 612);
            this.Controls.Add(this.pause);
            this.Controls.Add(this.play);
            this.Controls.Add(this.speechText);
            this.Controls.Add(this.writeText);
            this.Controls.Add(this.disableTextSpeech);
            this.Controls.Add(this.enableTextSpeech);
            this.Controls.Add(this.disableSpeak);
            this.Controls.Add(this.enableSpeak);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button enableSpeak;
        private System.Windows.Forms.Button disableSpeak;
        private System.Windows.Forms.Button enableTextSpeech;
        private System.Windows.Forms.Button disableTextSpeech;
        private System.Windows.Forms.RichTextBox writeText;
        private System.Windows.Forms.RichTextBox speechText;
        private System.Windows.Forms.Button play;
        private System.Windows.Forms.Button pause;
    }
}

