﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Speech.Recognition;
using System.Speech.Synthesis;
using System.Media;

namespace OOAD_Project
{
    public partial class Form1 : Form
    { 
        SoundPlayer Player = new SoundPlayer(@"c:\guitarup_raw.wav");
        SpeechRecognitionEngine srEngine = new SpeechRecognitionEngine();
        SpeechSynthesizer spEngine = new SpeechSynthesizer();
        public Form1()
        {
            InitializeComponent();
        }

        private void enableSpeak_Click(object sender, EventArgs e)
        {
            srEngine.RecognizeAsync(RecognizeMode.Multiple);
            disableSpeak.Enabled = true;
            enableTextSpeech.Enabled = false;
            disableTextSpeech.Enabled = false;
            if (enableSpeak.Enabled == true)
                enableSpeak.Enabled = false;
        }

        private void disableSpeak_Click(object sender, EventArgs e)
        {
            srEngine.RecognizeAsyncStop();
            disableSpeak.Enabled = false;
            enableTextSpeech.Enabled = true;
            disableTextSpeech.Enabled = true;
            enableSpeak.Enabled = true;
        }

        private void enableTextSpeech_Click(object sender, EventArgs e)
        {
            spEngine.SpeakAsync(writeText.Text);
            disableTextSpeech.Enabled = true;
            enableSpeak.Enabled = false;
            if (enableTextSpeech.Enabled == true)
            enableTextSpeech.Enabled = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Choices commands = new Choices();
            commands.Add(new string[] { "suneel", "murder", "open computer", "open word" });
            GrammarBuilder GBuild = new GrammarBuilder();
            GBuild.Append(commands);
            Grammar grammer = new Grammar(GBuild);

            srEngine.LoadGrammarAsync(grammer);
            srEngine.SetInputToDefaultAudioDevice();
            srEngine.SpeechRecognized += new EventHandler<SpeechRecognizedEventArgs>(srEngine_SpeechRecognized);
        }
        void srEngine_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            // spEngine.SpeakAsync(speechToText.Text);

            speechText.Text += e.Result.Text;

            switch (e.Result.Text)
            {
                case "suneel":
                  
                    spEngine.SpeakAsync("zohaib");

                    break;
                case "murder":
                    spEngine.SpeakAsync("executed");
                    
                    break;
                    //case "open computer":
                    //    if (e.Result.Text == "open computer")
                    //    {
                    //        string myComputerPath = Environment.GetFolderPath(Environment.SpecialFolder.MyComputer);
                    //        System.Diagnostics.Process.Start("explorer", myComputerPath);
                    //    }
                    //    break;
                    //case "open word":
                    //    if (e.Result.Text == "open word")
                    //    {
                    //        var applicationWord = new Microsoft.Office.Interop.Word.Application();
                    //        applicationWord.Visible = true;
                    //    }
                    //    break;
            }
        }

        private void disableTextSpeech_Click(object sender, EventArgs e)
        {
            spEngine.SpeakAsyncCancelAll();
            enableTextSpeech.Enabled = true;
            enableSpeak.Enabled = true;
            if (disableTextSpeech.Enabled == true)
                disableTextSpeech.Enabled = false;
        }

        private void writeText_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void speechText_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void play_Click(object sender, EventArgs e)
        {
            if (play.Enabled==true)
            {
            
               
                Player.Play();
                pause.Enabled = true;
                play.Enabled = false;
            }

        }

        private void pause_Click(object sender, EventArgs e)
        {
            if (pause.Enabled == true)
            {
                Player.Stop();
                pause.Enabled = false;
                play.Enabled = true;
            }
        }
    }


}
